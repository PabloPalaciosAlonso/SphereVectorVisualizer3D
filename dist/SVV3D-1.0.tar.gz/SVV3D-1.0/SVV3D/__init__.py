import vpython as vp

color = {}
color[0] = vp.vector(1,1,1) #blanco
color[1] = vp.vector(50,250,50)/255 #verde
color[2] = vp.vector(30,144,255)/255 #azul
color[3] = vp.vector(230,50,52)/255 #rojo
color[4] = vp.vector(250,128,0)/255 #naranja
color[5] = vp.vector(204,169,221)/255 #morado
color[6] = vp.vector(204,204,204)/255 #gris
color[7] = vp.vector(0,0,0) # Negro
